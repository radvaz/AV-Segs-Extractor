#include <iostream>
#include <stdio.h>
#include <time.h>
using namespace std;

int main()
{
    time_t rawtime;
    struct tm * ptm;
    int UTC = 0;
    time ( &rawtime );
    ptm = gmtime ( &rawtime );
    FILE * pFile;
    //pFile = fopen ("my_auto_manifest.mpd", "w");
    pFile = fopen ("my_auto_manifest_rodrigo_static.mpd", "w");
    //pFile = fopen ("my_auto_manifest_rodrigo_dynamic.mpd", "w");

    fprintf (pFile, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
    fprintf (pFile, "<MPD availabilityStartTime=\"%d-%02d-%dT%2d:%02d:%02dZ\"\n", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday, (ptm->tm_hour+UTC)%24, ptm->tm_min, ptm->tm_sec);
    fprintf (pFile, "	maxSegmentDuration=\"PT2.006S\"\n");
    fprintf (pFile, "	minBufferTime=\"PT2S\"\n");
    fprintf (pFile, "	minimumUpdatePeriod=\"PT0S\"\n");
    fprintf (pFile, "	profiles=\"urn:mpeg:dash:profile:isoff-live:2011\"\n");
    fprintf (pFile, "	publishTime=\"%d-%02d-%dT%2d:%02d:%02dZ\"\n", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday, (ptm->tm_hour+UTC)%24, ptm->tm_min, ptm->tm_sec);
    fprintf (pFile, "	timeShiftBufferDepth=\"PT12S\"\n");
    fprintf(pFile, "	type=\"static\"\n");
    //fprintf (pFile, "	type=\"dynamic\"\n");
    fprintf (pFile, "	xmlns=\"urn:mpeg:dash:schema:mpd:2011\"\n");
    fprintf (pFile, "	xmlns:cenc=\"urn:mpeg:cenc:2013\"\n");
    fprintf (pFile, "	xmlns:scte35=\"http://www.scte.org/schemas/35/2016\"\n");
    fprintf (pFile, "	xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n");
    fprintf (pFile, "	xsi:schemalocation=\"urn:mpeg:dash:schema:mpd:2011 DASH-MPD.xsd\">\n");
    fprintf (pFile, "   <Period id=\"P0\" start=\"PT0S\">\n");
    //fprintf (pFile, "      <AdaptationSet contentType=\"video\" id=\"0\" maxFrameRate=\"30000/1001\" maxHeight=\"720\" maxWidth=\"1280\" mimeType=\"video/mp4\" minFrameRate=\"30000/1001\" minHeight=\"480\" minWidth=\"720\" par=\"3:2\" segmentAlignment=\"true\" startWithSAP=\"1\">\n");
    fprintf(pFile, "      <AdaptationSet contentType=\"video\" id=\"0\" maxFrameRate=\"30000/1001\" maxHeight=\"2160\" maxWidth=\"3840\" mimeType=\"video/mp4\" minFrameRate=\"30000/1001\" minHeight=\"1080\" minWidth=\"1920\" par=\"16:9\" segmentAlignment=\"true\" startWithSAP=\"1\">\n");
    fprintf (pFile, "         <Role schemeIdUri=\"urn:mpeg:dash:role:2011\" value=\"main\"/>\n");
    //fprintf (pFile, "         <Representation bandwidth=\"2000000\" codecs=\"hvc1.1.6.L90.11\" frameRate=\"30000/1001\" height=\"480\" id=\"Video1_1\" sar=\"32:27\" scanType=\"Progressive\" width=\"720\">\n");
    fprintf(pFile, "         <Representation bandwidth=\"2000000\" codecs=\"hvc1.1.6.L120.11\" frameRate=\"30000/1001\" height=\"1080\" id=\"Video1_1\" sar=\"1:1\" scanType=\"Progressive\" width=\"1920\">\n");
    //fprintf (pFile, "            <SegmentTemplate duration=\"2002000\" initialization=\"video-$Bandwidth$-init.mp4\" media=\"video-$Bandwidth$-$Number$.mp4v\" startNumber=\"1\" timescale=\"1000000\"/>\n");
    fprintf(pFile, "            <SegmentTemplate duration=\"2002000\" initialization=\"video-$Bandwidth$-init.mp4\" media=\"video-$Bandwidth$-$Number$.mp4v\" startNumber=\"2\" timescale=\"1000000\"/>\n");
    fprintf (pFile, "         </Representation>\n");
    //fprintf (pFile, "         <Representation bandwidth=\"2500000\" codecs=\"lhe1.1.6.L93.11\" dependencyId=\"Video1_1\" frameRate=\"30000/1001\" height=\"720\" id=\"Video1_2\" sar=\"1:1\" scanType=\"Progressive\" width=\"1280\">\n");
    fprintf(pFile, "         <Representation bandwidth=\"2500000\" codecs=\"lhe1.1.6.L150.11\" dependencyId=\"Video1_1\" frameRate=\"30000/1001\" height=\"2160\" id=\"Video1_2\" sar=\"1:1\" scanType=\"Progressive\" width=\"3840\">\n");
    //fprintf (pFile, "            <SegmentTemplate duration=\"2002000\" initialization=\"video-$Bandwidth$-init.mp4\" media=\"video-$Bandwidth$-$Number$.mp4v\" startNumber=\"1\" timescale=\"1000000\"/>\n");
    fprintf(pFile, "            <SegmentTemplate duration=\"2002000\" initialization=\"video-$Bandwidth$-init.mp4\" media=\"video-$Bandwidth$-$Number$.mp4v\" startNumber=\"2\" timescale=\"1000000\"/>\n");
    fprintf (pFile, "         </Representation>\n");
    fprintf (pFile, "      </AdaptationSet>\n");
    fprintf (pFile, "      <AdaptationSet contentType=\"audio\" id=\"1\" mimeType=\"audio/mp4\" segmentAlignment=\"true\" startWithSAP=\"1\">\n");
    fprintf (pFile, "         <Representation audioSamplingRate=\"48000\" bandwidth=\"96000\" codecs=\"mp4a.40.5\" id=\"Audio2_3\">\n");
    fprintf (pFile, "            <AudioChannelConfiguration schemeIdUri=\"urn:mpeg:dash:23003:3:audio_channel_configuration:2011\" value=\"2\"/>\n");
    fprintf (pFile, "            <SegmentTemplate duration=\"96096\" initialization=\"audio-0-$Bandwidth$-init.mp4\" media=\"audio-0-$Bandwidth$-$Number$.mp4a\" startNumber=\"1\" timescale=\"48000\"/>\n");
    fprintf (pFile, "         </Representation>\n");
    fprintf (pFile, "      </AdaptationSet>\n");
    fprintf (pFile, "   </Period>\n");
    fprintf (pFile, "</MPD>\n");

    fclose (pFile);
    return 0;
}
