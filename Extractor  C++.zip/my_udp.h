//modified from  https://www.geeksforgeeks.org/tcp-server-client-implementation-in-c/
// and https://www.geeksforgeeks.org/udp-server-client-implementation-c/
//and https://www.csd.uoc.gr/~hy556/material/tutorials/cs556-3rd-tutorial.pdf
// and https://docs.oracle.com/cd/E19455-01/806-1017/sockets-137/index.html
#ifndef INC_MY_UDP_H_
#define INC_MY_UDP_H_
#include <netdb.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <sys/socket.h>
#include <fcntl.h> /* Added for the nonblocking socket */
#include <string>
#include <cstring>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/types.h>



#define MAX_BUFFER_SIZE						8192
#define MAX_BUFFER_DEPTH 					1
#define TYPE_SERVER 						0
#define TYPE_CLIENT 						1

#define RANGE_UNICAST						0
#define RANGE_MULTICAST						1


#define UDP_STATUS_CLOSED					0
#define UDP_STATUS_SOCKET_CREATED 			1
#define UDP_STATUS_BINDED					2
#define UDP_STATUS_LISTENING				3
#define UDP_STATUS_CONNECTED				4
#define UDP_STATUS_ACCEPTED					5

#define UDP_STATUS_SOCKET_CREATION_ERROR	-1
#define UDP_STATUS_BINDING_ERROR			-2
#define UDP_STATUS_LISTENING_ERROR			-3
#define UDP_STATUS_CONNECTING_ERROR			-4
#define UDP_STATUS_ACCEPTING_ERROR			-5
#define UDP_STATUS_OTHER_ERROR				-6

#define MESSAGE_STATUS_FREE					0
#define MESSAGE_STATUS_CAPTURED				1
#define MESSAGE_STATUS_READY_TO_RELEASE		2

struct udp_message
{
	int status;
	long int delay_time;
	char buffer[MAX_BUFFER_SIZE];
	int recieve_order;
	int destination;
	int length;
};


class udp_socket
{
private:
public:
	struct sockaddr_in server,client;
	int allow_out_of_order_release;
	int socket_fd, connection_fd;
	int status;
	int type;
	int range;
	udp_message* message_buffer;
	int message_counter;
	char* link_buffer;
	float buffer_occupancy;
	long unsigned int server_sent_packets;
	long unsigned int server_received_packets;
	long unsigned int client_sent_packets;
	long unsigned int client_received_packets;
	int next_catch_location;

	udp_socket();
	~udp_socket();

	const char* address;
	const char* interface;
	int port;
	void set_type(int _type);
	void set_buffer(udp_message* buffer);
	void init();
	int transmit(udp_message* message);
	int receive(udp_message* message);
	void print_packet_status();
	int get_status();
	void catch_packet();
	void release_packet();
	void analyze_buffer_occupancy();
	int lowest_recieve_order;
	void print();
	int extract_data(unsigned char* buffer,int start, int length);

};




#endif
