#include "my_udp.h"

udp_socket::udp_socket(){
	type=TYPE_SERVER;
	range=RANGE_UNICAST;
	socket_fd=0;
	connection_fd=0;
	status=UDP_STATUS_CLOSED;
	address="0.0.0.0";
	interface="0.0.0.0";
	port=0;
	message_counter=0;
	server_sent_packets=0;
	server_received_packets=0;
	client_sent_packets=0;
	client_received_packets=0;
	bzero(&server, sizeof(server));
	bzero(&client, sizeof(client));
	allow_out_of_order_release=0;
	next_catch_location=0;

}
udp_socket::~udp_socket()
{
	if(socket_fd>0)
	{
		close(socket_fd);
	}
}


void udp_socket::init()
{
	if(status==UDP_STATUS_CLOSED)
	{
		if(type==TYPE_SERVER)
		{
			socket_fd = socket(AF_INET, SOCK_DGRAM, 0);// socket create and verification

			if (socket_fd == -1)
			{
				status=UDP_STATUS_SOCKET_CREATION_ERROR;
				std::cout<<"Error-Server socket can't be created"<<std::endl;
				exit(-1);
			}
			else
			{
				if (range==RANGE_MULTICAST)
				{
					struct ip_mreq mreq;
					mreq.imr_multiaddr.s_addr=inet_addr(address);
					mreq.imr_interface.s_addr=inet_addr(interface);
					setsockopt(socket_fd, IPPROTO_IP, IP_ADD_MEMBERSHIP, &mreq, sizeof(mreq));
				}
				if(range==RANGE_UNICAST)
				{
					struct in_addr _interface;
					_interface.s_addr=inet_addr(interface);
					setsockopt(socket_fd, IPPROTO_IP, IP_UNICAST_IF, &_interface, sizeof(_interface));
					server.sin_addr.s_addr = inet_addr(address);
				}
				server.sin_family = AF_INET; // assign IP, PORT
				server.sin_port = htons((uint16_t)port);
				status=UDP_STATUS_SOCKET_CREATED;
				std::cout<<"Server socket is created"<<std::endl;
			}
			if ((bind(socket_fd, (struct sockaddr*)&server, sizeof(server))) != 0)// Binding newly created socket to given IP and verification
			{
				status=UDP_STATUS_BINDING_ERROR;
				std::cout<<"Error-Server socket can't be binded"<<std::endl;
				exit(-1);
			}
			else
			{
				status=UDP_STATUS_BINDED;
				std::cout<<"Server socket is binded"<<std::endl;
			}

			fcntl(socket_fd, F_SETFL, O_NONBLOCK); // Make the socket non blocking

		}
		if(type==TYPE_CLIENT)
		{
			socket_fd = socket(AF_INET, SOCK_DGRAM, 0);// socket create and verification
			if (socket_fd == -1)
			{
				status=UDP_STATUS_SOCKET_CREATION_ERROR;
				std::cout<<"Error-Client socket can't be created"<<std::endl;
				exit(-1);
			}
			else
			{
				struct in_addr _interface;
				_interface.s_addr=inet_addr(interface);
				if(range==RANGE_MULTICAST)
				{
					u_char _ttl=IP_DEFAULT_MULTICAST_TTL;
					setsockopt(socket_fd, IPPROTO_IP, IP_MULTICAST_IF, &_interface, sizeof(_interface));
					setsockopt(socket_fd, IPPROTO_IP, IP_MULTICAST_TTL, &_ttl, sizeof(_ttl));
				}
				if(range==RANGE_UNICAST)
				{
					setsockopt(socket_fd, IPPROTO_IP, IP_UNICAST_IF, &_interface, sizeof(_interface));
				}
				server.sin_family = AF_INET; // assign IP, PORT
				server.sin_addr.s_addr = inet_addr(address);
				server.sin_port = htons(port);
				status=UDP_STATUS_SOCKET_CREATED;
				std::cout<<"Client socket is created"<<std::endl;

			}

			fcntl(socket_fd, F_SETFL, O_NONBLOCK); // Make the socket non blocking
		}
	}

}

void udp_socket::set_buffer(udp_message* buffer)
{
	if(buffer!=0)
	{
		message_buffer=buffer;
		for(int i=0;i<MAX_BUFFER_DEPTH;i++)
		{
			(message_buffer+i)->delay_time=0;
		}
	}
}

int udp_socket::transmit(udp_message* message)
{
	int n=0;
	if (type==TYPE_SERVER)
	{
		sendto(socket_fd, message->buffer, message->length,MSG_CONFIRM, (const struct sockaddr *) &client,sizeof(client));
		server_sent_packets++;
	}
	else if(type==TYPE_CLIENT)
	{
		sendto(socket_fd, message->buffer, message->length,MSG_CONFIRM, (const struct sockaddr *) &server,sizeof(server));
		client_sent_packets++;
	}

	return n;
}

int udp_socket::receive(udp_message* message)
{
	int n=0;
	unsigned int len;
	if (type==TYPE_SERVER)
	{
		len= sizeof(client);
		n = recvfrom(socket_fd, message->buffer, MAX_BUFFER_SIZE,MSG_WAITALL, ( struct sockaddr *) &client, &len);
		if(n>0)
		{
			message->length=n;
			message->status=MESSAGE_STATUS_CAPTURED;
			message->destination=TYPE_CLIENT;
			server_received_packets++;
		}
		//		if (n>0)
		//		std::cout<<"from "<<inet_ntoa(client.sin_addr)<<std::endl;
	}
	else if(type==TYPE_CLIENT)
	{
		len= sizeof(server);
		n = recvfrom(socket_fd, message->buffer, MAX_BUFFER_SIZE,MSG_WAITALL, (struct sockaddr *) &server,&len);
		if(n>0)
		{
			message->length=n;
			message->status=MESSAGE_STATUS_CAPTURED;
			message->destination=TYPE_SERVER;
			client_received_packets++;
		}
	}

	return n;
}

int udp_socket::get_status()
{
	return status;
}

void udp_socket::set_type(int _type)
{
	if (_type==TYPE_SERVER)
	{
		type=TYPE_SERVER;
	}
	else if(_type==TYPE_CLIENT)
	{
		type=TYPE_CLIENT;
	}
	else
	{
		std::cout<< "wrong type"<<std::endl;
		exit(-1);
	}
}

void udp_socket::print_packet_status()
{
	if (type==TYPE_SERVER)
	{
		std::cout<<"Server: Packets Received= "<<server_received_packets<<" Packets sent= "<<server_sent_packets<<std::endl;

	}
	else if(type==TYPE_CLIENT)
	{
		std::cout<<"Client: Packets Received= "<<client_received_packets<<" Packets sent= "<<client_sent_packets<<std::endl;

	}
}

void udp_socket::catch_packet()
{
	int i;
	for(i=next_catch_location;i<MAX_BUFFER_DEPTH;i++)
	{
		if(message_buffer[i].status==MESSAGE_STATUS_FREE)
		{
			if(receive(&message_buffer[i])>0)
			{
				message_buffer[i].recieve_order=message_counter++;
				next_catch_location=i+1;
			}
			break;
		}
	}
	if(i==MAX_BUFFER_DEPTH)
	{
		for(i=0;i<next_catch_location;i++)
		{
			if(message_buffer[i].status==MESSAGE_STATUS_FREE)
			{
				if(receive(&message_buffer[i])>0)
				{
					message_buffer[i].recieve_order=message_counter++;
					next_catch_location=i+1;
				}
				break;
			}
		}
	}
}

void udp_socket::release_packet()
{
	long int time_since_rec=9999;
	int lowest_recieve_order_location=0;
	for(int i=0;i<MAX_BUFFER_DEPTH;i++)
	{
		if(message_buffer[i].status==MESSAGE_STATUS_CAPTURED)
		{
			if(time_since_rec>message_buffer[i].delay_time)
			{
				if(allow_out_of_order_release==1 && message_buffer[i].destination==type)
				{
					transmit(&message_buffer[i]);
					message_buffer[i].status=MESSAGE_STATUS_FREE;
				}
				else
				{
					message_buffer[i].status=MESSAGE_STATUS_READY_TO_RELEASE;

				}

			}
		}
	}

	if(allow_out_of_order_release==0)
	{
		for(int i=0;i<MAX_BUFFER_DEPTH;i++) // find the first captured
		{
			if(message_buffer[i].status!=MESSAGE_STATUS_FREE)
			{
				lowest_recieve_order=message_buffer[i].recieve_order;
				lowest_recieve_order_location=i;
				break;
			}
		}
		for(int i=0;i<MAX_BUFFER_DEPTH;i++) // find the lowest captured
		{
			if(message_buffer[i].recieve_order<lowest_recieve_order && message_buffer[i].status!=MESSAGE_STATUS_FREE)
			{
				lowest_recieve_order=message_buffer[i].recieve_order;
				lowest_recieve_order_location=i;
			}
		}


		if(message_buffer[lowest_recieve_order_location].status==MESSAGE_STATUS_READY_TO_RELEASE && message_buffer[lowest_recieve_order_location].destination==type)
		{
			transmit(&message_buffer[lowest_recieve_order_location]);
			message_buffer[lowest_recieve_order_location].status=MESSAGE_STATUS_FREE;
		}

	}
}

void udp_socket::analyze_buffer_occupancy()
{
	int occupied_locations=0;
	for(int i=0;i<MAX_BUFFER_DEPTH;i++)
	{
		if(message_buffer[i].status!=MESSAGE_STATUS_FREE)
		{
			occupied_locations++;
		}
	}
	buffer_occupancy=((float)occupied_locations)/MAX_BUFFER_DEPTH;
}
using std::hex;
void udp_socket::print()
{
	for(int i=0;i<MAX_BUFFER_DEPTH;i++)
	{
		if(message_buffer[i].status!=MESSAGE_STATUS_FREE)
		{
			std::cout<<"Message ["<<i<<"]"<<std::endl;
			for(int j=0;j<message_buffer[i].length;j++)
			{
				std::cout<<"0x" << std::hex<<(int)(unsigned char)message_buffer[i].buffer[j]<<" ";
				if(j!=0 && (j+1)%10 == 0)
				{
					std::cout<<std::endl;
				}
			}
			std::cout<<std::endl;
			message_buffer[i].status=MESSAGE_STATUS_FREE;
		}
	}
}

int udp_socket::extract_data(unsigned char* buffer,int start, int length)
{
	int ret_val=0;
	if((start+length)<MAX_BUFFER_SIZE)
	{
		for(int i=start;i<MAX_BUFFER_SIZE;i++)
		{
			if (i<(start+length))
			{
				*(buffer+i)=(unsigned char)message_buffer[0].buffer[i];
			}
			else
			{
				*(buffer+i)=0;
			}

		}
	}
	else
	{
		ret_val=-1;
	}
	return ret_val;
}
