//UDP Recorder V 0.2

#include "my_udp.h"
#include <bitset>
#include <string>
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <time.h>
#include <iomanip>

using namespace std; //makes std:: optional dghmdghmdghmdghmdghm

#define XML_INDICATOR 				0x00
#define BL_INDICATOR 				0x64
#define EL_INDICATOR				0x65
#define AUDIO_INDICATOR				0xC8
#define CP_XML						0x00
#define CP_AV						0x08
#define TOI_XML_PKT_1				0x0
#define TOI_XML_OTHERS				0x070010
#define TOI_SEG_1					0x01
#define TOI_SEG_2					0x02
#define FRAGMENT_3					0x0AE0
#define FRAGMENT_4					0x1058
#define FRAGMENT_5					0x15D0
#define HDR_LEN_36_BYTES			0x08
#define HDR_LEN_20_BYTES			0x04
#define MAX_UDP_PACK_LENGTH			1420 // 1420 via colasoft | 1492 via pkt sender
#define INIT_2M_PACK_LENGTH			898  //  898 via colasoft | 938  via pkt sender
#define INIT_2M5_CONTINUITY_LENGTH  298  //  298 via colasoft | 340  via pkt sender
#define MDP_FINAL_PACK_LENGTH		391  //  via colasoft
#define UDP_HEADER_LENGTH  			42 // UDP 	payload starts
#define ROUTE_LONG_HEADER   		36 // 32 => colasoft | PKT sender => 78 // UDP + ROUTE long header payload starts  (42 + 36)
#define ROUTE_SHORT_HEADER	 		20 // 20 => colasoft | PKT sender => 62 // UDP + ROUTE short header payload starts (42 + 20)
#define ENDING_CONTROL				49725 // total de pacotes do .pcap de provas

int main() {

  udp_socket server;
  udp_message* message_buffer=new udp_message[MAX_BUFFER_DEPTH];
  unsigned char data_buffer[MAX_BUFFER_SIZE];
  unsigned char dataBufferPktInit2M[MAX_BUFFER_SIZE];

  std::fstream output_file_txt;
  std::ofstream output_file_bin;

  std::ofstream video_2M_1_init_mp4;
  video_2M_1_init_mp4.open("video-2000000-init.mp4",std::ios::binary | std::ios::out);

  std::ofstream video_2M5_mp4;
  video_2M5_mp4.open("video-2500000-init.mp4",std::ios::binary | std::ios::out);

  std::ofstream manifest_mpd;
  manifest_mpd.open("manifest.mpd",std::ios::binary | std::ios::out);

  //FILE * pFile;
  //pFile = fopen ("my_auto_manifest.mpd", "w");
  //pFile = fopen ("manifest_rodrigo.mpd", "w");
  //pFile = fopen ("my_auto_manifest_rodrigo_dynamic.mpd", "w");

  std::ofstream bl_bin_file;
  std::ofstream el_bin_file;

  //server.address="239.2.60.2"; //PCAP files Multicast IP George
  server.address="239.255.60.2"; //PCAP files Multicast IP Dectek
  server.interface="127.0.0.1";
  server.port=6002;
  
  //joseS

  server.range=RANGE_MULTICAST;
  server.set_buffer(message_buffer);
  server.set_type(TYPE_SERVER);
  server.allow_out_of_order_release=0;

  server.init(); // to wait for a connection from the client

  int comp = MAX_UDP_PACK_LENGTH; // tamanho max do payload do pacote UDP recebido => maior pacote route do pcap set1

  int pkt_size, hdrLen, codepoint, pacote, tsi, toi, hel, hec, el_toi, loop_control = 1; // current_bl_seg, current_el_seg,
  int previous_bl_toi = 0, previous_bl_tsi = 0, previous_el_toi = 0, previous_el_tsi = 0, init_2M5_control = 0;
  std::string line, desired_bl_file_name, desired_el_file_name, toi_string;
  int offsetmin = 0;  //postpone (offsetmin +) or antecipate (offsetmin -) the field MPD availabilityStartTime => first test + 1min => worked ok.
  int offsetsec = 6; //postpone (offsetsec +) or antecipate (offsetsec -) the field MPD availabilityStartTime => first test + 1min => worked ok.


  // variables to create manifest.mpd
  time_t rawtime;
  struct tm * ptm;
  int UTC = 0;
  time ( &rawtime );
  ptm = gmtime ( &rawtime );

  while(1) {

    server.catch_packet();
	//server.print(); // imprime mensagem completa recebida
		
    server.extract_data(dataBufferPktInit2M,0,comp); // buffer, inicio, comprimento
    pkt_size = server.message_buffer->length;

    //server.extract_data(dataBufferPktInit2M,0,pkt_size); // buffer, inicio, comprimento

    std::cout<<std::endl;
    std::cout << "Tamanho do pkt recebido = " << std::dec <<  pkt_size << "bytes"<< std::endl;

    if(server.message_buffer[0].status!=MESSAGE_STATUS_FREE) {

	//debugging => aprendendo a mexer na plataforma
      std::cout<<std::endl;
      std::cout<<"Pacote recebido = "<<std::dec<<loop_control;
      std::cout<<std::endl;

      hdrLen = dataBufferPktInit2M[02]; // contagem feita com colasoft
	  std::cout<<"HDR_LEN = 0x" << std::hex << hdrLen <<std::endl; // print on screen

	  if (hdrLen == HDR_LEN_36_BYTES){ //0x8
	    std::cout<< "LCT header tem comprimento de 36 bytes" <<std::endl <<std::endl;
	  }
	  else //hdrLen == 0x4
        std::cout<< "LCT header tem comprimento de 20 bytes" <<std::endl <<std::endl;

      codepoint = dataBufferPktInit2M[03]; // contagem feita com colasoft
      std::cout<<"codepoint = 0x" << std::hex << codepoint <<std::endl; // print on screen
			
	  if (codepoint == CP_AV){ //0x8
	    std::cout<< "LCT PKT transporta segmento de A/V" <<std::endl <<std::endl;
	  }
	  else //codepoint == 0
        std::cout<< "LCT PKT transporta arquivo xml" <<std::endl <<std::endl;

      tsi = dataBufferPktInit2M[11]; // contagem feita com colasoft
      std::cout<<"TSI = 0x" << std::hex << tsi <<std::endl; // print on screen
			
	  switch (tsi){
	    case XML_INDICATOR: //0x0
	      std::cout<< "LCT PKT transporta dados de XML" <<std::endl <<std::endl;
		break;

	    case BL_INDICATOR: //0x64
		  std::cout<< "LCT PKT transporta segmentos de video do BL" <<std::endl <<std::endl;
	    break;

	    case EL_INDICATOR: //0x65
	     std::cout<< "LCT PKT transporta segmentos de video do EL" <<std::endl <<std::endl;
	    break;

	    case AUDIO_INDICATOR: // 0xC8
	      std::cout<< "LCT PKT transporta audio" <<std::endl <<std::endl;
	    break;
	  }

	  toi = dataBufferPktInit2M[12]*0x100*0x100*0x100 + dataBufferPktInit2M[13]*0x100*0x100 + dataBufferPktInit2M[14]*0x100 + dataBufferPktInit2M[15]; // contagem feita com conteudo do colasoft
	  std::cout<<"TOI = 0x" << std::hex << toi <<std::endl; // print on screen

	  switch (toi){ // feito somente ate o 4o segmento de video
	    case 0x1:
	  	  std::cout<< "LCT PKT transporta dados do 1º segmento de video" <<std::endl <<std::endl;
	  	break;

  	    case 0x2:
  		  std::cout<< "LCT PKT transporta dados do 2º segmento de video" <<std::endl <<std::endl;
  	    break;

  	    case 0x3:
  	      std::cout<< "LCT PKT transporta dados do 3º segmento de video" <<std::endl <<std::endl;
  	    break;

  	    case 0x4:
  	      std::cout<< "LCT PKT transporta dados do 4º segmento de video" <<std::endl <<std::endl;
  	    break;

  	    case 0x70010:
  	      std::cout<< "LCT PKT transporta dados XML/MPD" <<std::endl <<std::endl;
  	    break;
	  } //Debugging end

	  /*
	  // Extracts manifest.mpd file from .pcap flow
	  if ((hdrLen == HDR_LEN_20_BYTES) && (codepoint == CP_XML) && (tsi == XML_INDICATOR) && (toi == TOI_XML_OTHERS)){
        hel = dataBufferPktInit2M[17]; // contagem feita com conteudo do colasoft
    	std::cout<<"HEL = 0x" << std::hex << hel <<std::endl;

        hec = dataBufferPktInit2M[18]*0x100 + dataBufferPktInit2M[19]; // contagem feita com conteudo do colasoft
        std::cout<<"HEC = 0x" << std::hex << hec <<std::endl;

        if (hel == 0x0) { //
          switch (hec){
            case FRAGMENT_3: //0x0AE0
          	  for (int j=ROUTE_SHORT_HEADER+942; j<MAX_UDP_PACK_LENGTH; j++){
                manifest_mpd.write((const char*)&dataBufferPktInit2M[j],sizeof(char));
              }
            break;

            case FRAGMENT_4: //0x1058
              for (int j=ROUTE_SHORT_HEADER; j<MAX_UDP_PACK_LENGTH; j++){ //j deve comecar no inicio do buffer e crescer ate seu comprimento => comp. header route 36 bytes no caso do init 2M
                manifest_mpd.write((const char*)&dataBufferPktInit2M[j],sizeof(char));
              }
            break;

            case FRAGMENT_5: //0x15D0
        	  for (int j=ROUTE_SHORT_HEADER; j<MDP_FINAL_PACK_LENGTH; j++){ //j deve comecar no inicio do buffer e crescer ate seu comprimento => comp. header route 36 bytes no caso do init 2M
        	    manifest_mpd.write((const char*)&dataBufferPktInit2M[j],sizeof(char));
              }
        	  manifest_mpd.flush();//descarrega memoria antes de fechar.
        	  manifest_mpd.close();
            break;
          }
        }
      }
      */

	  // Prints coordinates on manifest.mpd file according to programmer needs
	  manifest_mpd <<"<?xml version=\"1.0\" encoding=\"UTF-8\"?>" << std::endl;
  	  //manifest_mpd << "<MPD availabilityStartTime=\"" << std::dec << ptm->tm_year+1900 << "-" << std::setfill ('0') << setw(2) << std::dec << ptm->tm_mon+1 << "-" << std::dec << ptm->tm_mday << "T" << std::setfill ('0')<< setw(2) << std::dec << (ptm->tm_hour+UTC)%24 << ":" << std::setfill ('0')<< setw(2) << std::dec << ptm->tm_min << ":" << std::setfill ('0')<< setw(2) << std::dec << ptm->tm_sec << "Z\"" << std::endl;

	  // +1 min smanifest_mpd << "<MPD availabilityStartTime=\"" << std::dec << ptm->tm_year+1900 << "-" << std::setfill ('0') << setw(2) << std::dec << ptm->tm_mon+1 << "-" << std::dec << ptm->tm_mday << "T" << std::setfill ('0')<< setw(2) << std::dec << (ptm->tm_hour+UTC)%24 << ":" << std::setfill ('0')<< setw(2) << std::dec << ptm->tm_min << ":" << std::setfill ('0')<< setw(2) << std::dec << ptm->tm_sec << "Z\"" << std::endl;
	  // Na pratica, a latencia/delay em casa é de uns 22 s. como ajustar este valor?
	  manifest_mpd << "<MPD availabilityStartTime=\"" << std::dec << ptm->tm_year+1900 << "-" << std::setfill ('0') << setw(2) << std::dec << ptm->tm_mon+1 << "-" << std::dec << ptm->tm_mday << "T" << std::setfill ('0')<< setw(2) << std::dec << (ptm->tm_hour+UTC)%24 << ":" << std::setfill ('0')<< setw(2) << std::dec << ptm->tm_min+offsetmin << ":" << std::setfill ('0')<< setw(2) << std::dec << ptm->tm_sec+offsetsec << "Z\"" << std::endl;
	  manifest_mpd << "    maxSegmentDuration=\"PT2.006S\"" << std::endl; // Poderia ser este o controile de latencia??

	  manifest_mpd << "    minBufferTime=\"PT2S\"" << std::endl; // original ateme
	  //manifest_mpd << "    minBufferTime= \"PT10S\"" << std::endl;

	  manifest_mpd << "    minimumUpdatePeriod=\"PT0S\"" << std::endl; // original ateme
	  //manifest_mpd << "    minimumUpdatePeriod=\"PT02S\"" << std::endl;

	  manifest_mpd << "    profiles=\"urn:mpeg:dash:profile:isoff-live:2011\"" << std::endl;
	  manifest_mpd << "    publishTime=\"" << std::dec << ptm->tm_year+1900 << "-" << std::setfill ('0') << setw(2) << std::dec << ptm->tm_mon+1 << "-" << std::dec << ptm->tm_mday << "T" << std::setfill ('0')<< setw(2) << std::dec << (ptm->tm_hour+UTC)%24 << ":" << std::setfill ('0')<< setw(2) << std::dec << ptm->tm_min << ":" << std::setfill ('0')<< setw(2) << std::dec << ptm->tm_sec << "Z\"" << std::endl;

	  manifest_mpd << "    timeShiftBufferDepth=\"PT12S\"" << std::endl; // original ateme
	  //manifest_mpd << "    timeShiftBufferDepth=\"PT0S\"" << std::endl;

	  manifest_mpd << "    suggestedPresentationDelay=\"PT2S\"" << std::endl; // inserido por mim
	  //manifest_mpd << "    Latency target=\"12000\" min=\"8000\" max\"16000\"" << std::endl; // inserido por mim

	  //manifest_mpd << "    type=\"static\"" << std::endl;
	  manifest_mpd << "    type=\"dynamic\"" << std::endl;
	  manifest_mpd << "    xmlns=\"urn:mpeg:dash:schema:mpd:2011\"" << std::endl;
	  manifest_mpd << "    xmlns:cenc=\"urn:mpeg:cenc:2013\"" << std::endl;
	  manifest_mpd << "    xmlns:scte35=\"http://www.scte.org/schemas/35/2016\"" << std::endl;
	  manifest_mpd << "    xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"" << std::endl;
	  manifest_mpd << "    xsi:schemalocation=\"urn:mpeg:dash:schema:mpd:2011 DASH-MPD.xsd\">" << std::endl;

	  //manifest_mpd << "    <BaseURL> http://192.168.0.3/linux </BaseURL>" << std::endl;
	  manifest_mpd << "    <BaseURL> http://192.168.0.40/paper_bts/ </BaseURL>" << std::endl; //BL
	  //manifest_mpd << "    <BaseURL> http://192.168.0.40/paper_bts/EL/ </BaseURL>" << std::endl; //EL
	  manifest_mpd << "    <BaseURL> http://192.168.0.49/el/ </BaseURL>" << std::endl; //EL
	  //manifest_mpd << "    <BaseURL> https://radvaz.s3.sa-east-1.amazonaws.com/el_test/ </BaseURL>" << std::endl; //EL
	  
	  //manifest_mpd << "    <BaseURL> http://192.168.0.40/teste </BaseURL>" << std::endl;
	  //manifest_mpd << "    <BaseURL> http://192.168.0.40/linux </BaseURL>" << std::endl;
	  //manifest_mpd << "    <BaseURL> http://10.0.63.18/bl </BaseURL>" << std::endl;
	  //manifest_mpd << "    <BaseURL> http://10.0.63.18/el </BaseURL>" << std::endl;
	  //manifest_mpd << "    <BaseURL> http://10.0.63.7:8080/uploads/6002 </BaseURL>" << std::endl;

	  //manifest_mpd << "    <BaseURL> http://192.168.0.3/teste_el </BaseURL>" << std::endl;
	  //manifest_mpd << "    <BaseURL> http://192.168.0.3/teste_bl </BaseURL>" << std::endl;
	  //manifest_mpd << "    <BaseURL> https://radvaz.s3.sa-east-1.amazonaws.com/el/ </BaseURL>" << std::endl;
	  //manifest_mpd << "    <BaseURL> https://storage.googleapis.com/shvc/EL/ </BaseURL>" << std::endl;

	  manifest_mpd << "    <Period id=\"P0\" start=\"PT0S\">" << std::endl; // original ateme
	  //manifest_mpd << "    <Period id=\"P0\" start=\"PT4S\">" << std::endl;

	  //manifest_mpd << "       <AdaptationSet contentType=\"video\" id=\"0\" maxFrameRate=\"30000/1001\" maxHeight=\"720\" maxWidth=\"1280\" mimeType=\"video/mp4\" minFrameRate=\"30000/1001\" minHeight=\"480\" minWidth=\"720\" par=\"3:2\" segmentAlignment=\"true\" startWithSAP=\"1\">" << std::endl;
	  manifest_mpd << "       <AdaptationSet contentType=\"video\" id=\"0\" maxFrameRate=\"30000/1001\" maxHeight=\"2160\" maxWidth=\"3840\" mimeType=\"video/mp4\" minFrameRate=\"30000/1001\" minHeight=\"1080\" minWidth=\"1920\" par=\"16:9\" segmentAlignment=\"true\" startWithSAP=\"1\">" << std::endl;
	  manifest_mpd << "          <Role schemeIdUri=\"urn:mpeg:dash:role:2011\" value=\"main\"/>" << std::endl;
	  //manifest_mpd <<          <Representation bandwidth=\"2000000\" codecs=\"hvc1.1.6.L90.11\" frameRate=\"30000/1001\" height=\"480\" id=\"Video1_1\" sar=\"32:27\" scanType=\"Progressive\" width=\"720\">" << std::endl;
	  manifest_mpd << "          <Representation bandwidth=\"2000000\" codecs=\"hvc1.1.6.L120.11\" frameRate=\"30000/1001\" height=\"1080\" id=\"Video1_1\" sar=\"1:1\" scanType=\"Progressive\" width=\"1920\">" << std::endl;
	  //manifest_mpd << "           <SegmentTemplate duration=\"2002000\" initialization=\"video-$Bandwidth$-init.mp4\" media=\"video-$Bandwidth$-$Number$.mp4v\" startNumber=\"1\" timescale=\"1000000\"/>" << std::endl;
	  //manifest_mpd << "           <SegmentTemplate duration=\"2002000\" initialization=\"video-$Bandwidth$-init.mp4\" media=\"video-$Bandwidth$-$Number$.mp4v\" startNumber=\"2\" timescale=\"1000000\"/>" << std::endl;
	  //manifest_mpd << "             <SegmentTemplate duration=\"2002000\" initialization=\"http://192.168.0.40/linux/video-$Bandwidth$-init.mp4\" media=\"http://192.168.0.40/linux/video-$Bandwidth$-$Number$.mp4v\" startNumber=\"2\" timescale=\"1000000\"/>" << std::endl;
	  manifest_mpd << "             <SegmentTemplate duration=\"2002000\" initialization=\"http://192.168.0.40/paper_bts/video-$Bandwidth$-init.mp4\" media=\"http://192.168.0.40/paper_bts/video-$Bandwidth$-$Number$.mp4v\" startNumber=\"2\" timescale=\"1000000\"/>" << std::endl;
	  //manifest_mpd << "             <SegmentTemplate duration=\"2002000\" initialization=\"http://10.0.63.18/bl/video-$Bandwidth$-init.mp4\" media=\"http://10.0.63.18/bl/video-$Bandwidth$-$Number$.mp4v\" startNumber=\"1\" timescale=\"1000000\"/>" << std::endl; //Dashserver - Laptop Dell
	  //manifest_mpd << "           <SegmentTemplate duration=\"2002000\" initialization=\"http://192.168.0.3/teste_bl/video-$Bandwidth$-init.mp4\" media=\"http://192.168.0.3/teste_bl/video-$Bandwidth$-$Number$.mp4v\" startNumber=\"2\" timescale=\"1000000\"/>" << std::endl;

	  manifest_mpd << "          </Representation>" << std::endl;
	  //manifest_mpd << "        <Representation bandwidth=\"2500000\" codecs=\"lhe1.1.6.L93.11\" dependencyId=\"Video1_1\" frameRate=\"30000/1001\" height=\"720\" id=\"Video1_2\" sar=\"1:1\" scanType=\"Progressive\" width=\"1280\">"<< std::endl;
	  manifest_mpd << "          <Representation bandwidth=\"2500000\" codecs=\"lhe1.1.6.L150.11\" dependencyId=\"Video1_1\" frameRate=\"30000/1001\" height=\"2160\" id=\"Video1_2\" sar=\"1:1\" scanType=\"Progressive\" width=\"3840\">" << std::endl;
	  //manifest_mpd << "             <SegmentTemplate duration=\"2002000\" initialization=\"video-$Bandwidth$-init.mp4\" media=\"video-$Bandwidth$-$Number$.mp4v\" startNumber=\"1\" timescale=\"1000000\"/>" << std::endl;
	  //manifest_mpd << "             <SegmentTemplate duration=\"2002000\" initialization=\"video-$Bandwidth$-init.mp4\" media=\"video-$Bandwidth$-$Number$.mp4v\" startNumber=\"2\" timescale=\"1000000\"/>" << std::endl;
	  //manifest_mpd << "             <SegmentTemplate duration=\"2002000\" initialization=\"https://radvaz.s3.sa-east-1.amazonaws.com/el/video-$Bandwidth$-init.mp4\" media=\"https://radvaz.s3.sa-east-1.amazonaws.com/el/video-$Bandwidth$-$Number$.mp4v\" startNumber=\"2\" timescale=\"1000000\"/>" << std::endl;
      //manifest_mpd << "             <SegmentTemplate duration=\"2002000\" initialization=\"https://radvaz.s3.sa-east-1.amazonaws.com/el_test/video-$Bandwidth$-init.mp4\" media=\"https://radvaz.s3.sa-east-1.amazonaws.com/el_test/video-$Bandwidth$-$Number$.mp4v\" startNumber=\"2\" timescale=\"1000000\"/>" << std::endl;
	  //manifest_mpd << "             <SegmentTemplate duration=\"2002000\" initialization=\"https://storage.googleapis.com/shvc/EL/video-$Bandwidth$-init.mp4\" media=\"https://storage.googleapis.com/shvc/EL/video-$Bandwidth$-$Number$.mp4v\" startNumber=\"2\" timescale=\"1000000\"/>" << std::endl;
	  //manifest_mpd << "             <SegmentTemplate duration=\"2002000\" initialization=\"http://192.168.0.40/linux/video-$Bandwidth$-init.mp4\" media=\"http://192.168.0.40/linux/video-$Bandwidth$-$Number$.mp4v\" startNumber=\"2\" timescale=\"1000000\"/>" << std::endl;

	  //manifest_mpd << "             <SegmentTemplate duration=\"2002000\" initialization=\"http://10.0.63.18/el/video-$Bandwidth$-init.mp4\" media=\"http://10.0.63.18/el/video-$Bandwidth$-$Number$.mp4v\" startNumber=\"1\" timescale=\"1000000\"/>" << std::endl;
	  //manifest_mpd << "             <SegmentTemplate duration=\"2002000\" initialization=\"http://10.0.63.7:8080/uploads/6002/video-$Bandwidth$-init.mp4\" media=\"http://10.0.63.7:8080/uploads/6002/video-$Bandwidth$-$Number$.mp4v\" startNumber=\"1\" timescale=\"1000000\"/>" << std::endl; // Ateme 

	  //manifest_mpd << "             <SegmentTemplate duration=\"2002000\" initialization=\"http://192.168.0.3/teste_el/video-$Bandwidth$-init.mp4\" media=\"http://192.168.0.3/teste_el/video-$Bandwidth$-$Number$.mp4v\" startNumber=\"2\" timescale=\"1000000\"/>" << std::endl;
	  //manifest_mpd << "             <SegmentTemplate duration=\"2002000\" initialization=\"http://192.168.0.40/teste_setup_mack/teste_el/video-$Bandwidth$-init.mp4\" media=\"http://192.168.0.40/teste_setup_mack/video-$Bandwidth$-$Number$.mp4v\" startNumber=\"2\" timescale=\"1000000\"/>" << std::endl;
	  //manifest_mpd << "             <SegmentTemplate duration=\"2002000\" initialization=\"http://192.168.0.40/paper_bts/EL/video-$Bandwidth$-init.mp4\" media=\"http://192.168.0.40/paper_bts/EL/video-$Bandwidth$-$Number$.mp4v\" startNumber=\"2\" timescale=\"1000000\"/>" << std::endl;
	  manifest_mpd << "             <SegmentTemplate duration=\"2002000\" initialization=\"http://192.168.0.40/paper_bts/ateme/video-$Bandwidth$-init.mp4\" media=\"http://192.168.0.40/paper_bts/ateme/video-$Bandwidth$-$Number$.mp4v\" startNumber=\"2\" timescale=\"1000000\"/>" << std::endl;
	  //manifest_mpd << "             <SegmentTemplate duration=\"2002000\" initialization=\"http://192.168.0.49/el/video-$Bandwidth$-init.mp4\" media=\"http://192.168.0.49/el/video-$Bandwidth$-$Number$.mp4v\" startNumber=\"2\" timescale=\"1000000\"/>" << std::endl;

	  manifest_mpd << "          </Representation>" << std::endl;
	  manifest_mpd << "       </AdaptationSet>" << std::endl;
	  manifest_mpd << "       <AdaptationSet contentType=\"audio\" id=\"1\" mimeType=\"audio/mp4\" segmentAlignment=\"true\" startWithSAP=\"1\">" << std::endl;
	  manifest_mpd << "          <Representation audioSamplingRate=\"48000\" bandwidth=\"96000\" codecs=\"mp4a.40.5\" id=\"Audio2_3\">" << std::endl;
	  manifest_mpd << "             <AudioChannelConfiguration schemeIdUri=\"urn:mpeg:dash:23003:3:audio_channel_configuration:2011\" value=\"2\"/>" << std::endl;
	  manifest_mpd << "             <SegmentTemplate duration=\"96096\" initialization=\"audio-0-$Bandwidth$-init.mp4\" media=\"audio-0-$Bandwidth$-$Number$.mp4a\" startNumber=\"1\" timescale=\"48000\"/>" << std::endl;
	  manifest_mpd << "          </Representation>" << std::endl;
	  manifest_mpd << "       </AdaptationSet> " << std::endl;
      manifest_mpd << "    </Period>" << std::endl;
	  manifest_mpd << "</MPD>" << std::endl;

	  manifest_mpd.flush();//descarrega memoria antes de fechar.
	  manifest_mpd.close();

	  // fechar o manifesto

	  // Extracting video_2000000_init.mp4
      if ((hdrLen == HDR_LEN_36_BYTES) && (codepoint == CP_AV) && (tsi == BL_INDICATOR) && (toi == TOI_SEG_1)){
    	  // Extração do video_2000000_init.mp4 a partir do pcap da Dektec
    	if ((dataBufferPktInit2M[ROUTE_LONG_HEADER]    ==  0x0) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +1] ==  0x0) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +2] ==  0x0) &&
    	    (dataBufferPktInit2M[ROUTE_LONG_HEADER +3] == 0x20) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +4] == 0x66) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +5] == 0x74) &&
    	    (dataBufferPktInit2M[ROUTE_LONG_HEADER +6] == 0x79) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +7] == 0x70) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +8] == 0x68) &&
    	    (dataBufferPktInit2M[ROUTE_LONG_HEADER +9] == 0x76) && (dataBufferPktInit2M[ROUTE_LONG_HEADER+10] == 0x63) && (dataBufferPktInit2M[ROUTE_LONG_HEADER+11] == 0x31) &&
    	    (dataBufferPktInit2M[pkt_size-13] == 0x10) && (dataBufferPktInit2M[pkt_size-12] == 0x73) && (dataBufferPktInit2M[pkt_size-11] == 0x74) &&
    	    (dataBufferPktInit2M[pkt_size-10] == 0x63) && (dataBufferPktInit2M[pkt_size -9] == 0x6F) && (dataBufferPktInit2M[pkt_size -8] == 0x00) &&
    	    (dataBufferPktInit2M[pkt_size -7] == 0x00) && (dataBufferPktInit2M[pkt_size -6] == 0x00) && (dataBufferPktInit2M[pkt_size -5] == 0x00) &&
    	    (dataBufferPktInit2M[pkt_size -4] == 0x00) && (dataBufferPktInit2M[pkt_size -3] == 0x00) && (dataBufferPktInit2M[pkt_size -2] == 0x00) &&
    	    (dataBufferPktInit2M[pkt_size -1] == 0x00)) { //posicoes determinadas com base no tamanho do pacote e posição dos hex no pacote

    	// Extracting video_2000000_init.mp4 from George Pcap
/*	    if ((dataBufferPktInit2M[ROUTE_LONG_HEADER]    ==  0x0) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +1] ==  0x0) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +2] ==  0x0) &&
		    (dataBufferPktInit2M[ROUTE_LONG_HEADER +3] == 0x20) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +4] == 0x66) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +5] == 0x74) &&
		    (dataBufferPktInit2M[ROUTE_LONG_HEADER +6] == 0x79) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +7] == 0x70) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +8] == 0x68) &&
		    (dataBufferPktInit2M[ROUTE_LONG_HEADER +9] == 0x76) && (dataBufferPktInit2M[ROUTE_LONG_HEADER+10] == 0x63) && (dataBufferPktInit2M[ROUTE_LONG_HEADER+11] == 0x31) &&
		    (dataBufferPktInit2M[INIT_2M_PACK_LENGTH-13] == 0x10) && (dataBufferPktInit2M[INIT_2M_PACK_LENGTH-12] == 0x73) && (dataBufferPktInit2M[INIT_2M_PACK_LENGTH-11] == 0x74) &&
		    (dataBufferPktInit2M[INIT_2M_PACK_LENGTH-10] == 0x63) && (dataBufferPktInit2M[INIT_2M_PACK_LENGTH -9] == 0x6F) && (dataBufferPktInit2M[INIT_2M_PACK_LENGTH -8] == 0x00) &&
		    (dataBufferPktInit2M[INIT_2M_PACK_LENGTH -7] == 0x00) && (dataBufferPktInit2M[INIT_2M_PACK_LENGTH -6] == 0x00) && (dataBufferPktInit2M[INIT_2M_PACK_LENGTH -5] == 0x00) &&
		    (dataBufferPktInit2M[INIT_2M_PACK_LENGTH -4] == 0x00) && (dataBufferPktInit2M[INIT_2M_PACK_LENGTH -3] == 0x00) && (dataBufferPktInit2M[INIT_2M_PACK_LENGTH -2] == 0x00) &&
		    (dataBufferPktInit2M[INIT_2M_PACK_LENGTH -1] == 0x00)) {//posicoes determinadas experimentalmente => colocar de forma indexada: 925+i */

          std::cout<<"Joa0 "<<std::endl<<std::endl;

          //for(int j=ROUTE_LONG_HEADER;j<INIT_2M_PACK_LENGTH;j++) { //j deve comecar no inicio do buffer e crescer ate seu comprimento => comp. header route 36 bytes no caso do init 2M
          for(int j=ROUTE_LONG_HEADER;j<pkt_size; j++){ //j deve comecar no inicio do buffer e crescer ate seu comprimento => comp. header route 36 bytes no caso do init 2M
            video_2M_1_init_mp4.write((const char*)&dataBufferPktInit2M[j],sizeof(char));
	      }
	      video_2M_1_init_mp4.flush();//descarrega memoria antes de fechar.
	      video_2M_1_init_mp4.close();
        }
	  }// video_2000000_init.mp4 extraction end

      //Extracting video_2500000_init.mp4
      if ((codepoint == CP_AV) && (tsi == EL_INDICATOR) && (toi == TOI_SEG_1)){
        switch (hdrLen){
          case HDR_LEN_36_BYTES: //0x08 - 1st portion of video_2500000_init.mp4 file
        	//Extração do video_2500000_init.mp4 a partir do pcap do George
/*        	if ((dataBufferPktInit2M[ROUTE_LONG_HEADER]   == 0x00) && (dataBufferPktInit2M[ROUTE_LONG_HEADER+1]  == 0x00) && (dataBufferPktInit2M[ROUTE_LONG_HEADER+2]  == 0x00) &&
        	    (dataBufferPktInit2M[ROUTE_LONG_HEADER+3] == 0x20) && (dataBufferPktInit2M[ROUTE_LONG_HEADER+4]  == 0x66) && (dataBufferPktInit2M[ROUTE_LONG_HEADER+5]  == 0x74) &&
				(dataBufferPktInit2M[ROUTE_LONG_HEADER+6] == 0x79) && (dataBufferPktInit2M[ROUTE_LONG_HEADER+7]  == 0x70) && (dataBufferPktInit2M[ROUTE_LONG_HEADER+8]  == 0x68) &&
				(dataBufferPktInit2M[ROUTE_LONG_HEADER+9] == 0x76) && (dataBufferPktInit2M[ROUTE_LONG_HEADER+10] == 0x63) && (dataBufferPktInit2M[ROUTE_LONG_HEADER+11]  == 0x31) &&
				(dataBufferPktInit2M[MAX_UDP_PACK_LENGTH-12] == 0x00) && (dataBufferPktInit2M[MAX_UDP_PACK_LENGTH-11] == 0x29) && (dataBufferPktInit2M[MAX_UDP_PACK_LENGTH-10] == 0x38) &&
        	    (dataBufferPktInit2M[MAX_UDP_PACK_LENGTH- 9] == 0x3b) && (dataBufferPktInit2M[MAX_UDP_PACK_LENGTH- 8] == 0x00) && (dataBufferPktInit2M[MAX_UDP_PACK_LENGTH- 7] == 0x00) &&
				(dataBufferPktInit2M[MAX_UDP_PACK_LENGTH- 6] == 0x03) && (dataBufferPktInit2M[MAX_UDP_PACK_LENGTH- 5] == 0x00) && (dataBufferPktInit2M[MAX_UDP_PACK_LENGTH- 4] == 0x05) &&
                (dataBufferPktInit2M[MAX_UDP_PACK_LENGTH- 3] == 0xfc) && (dataBufferPktInit2M[MAX_UDP_PACK_LENGTH- 2] == 0x40) && (dataBufferPktInit2M[MAX_UDP_PACK_LENGTH- 1] == 0x00)){ */

        	 //2ª Alternativa para Pcap do George
/*           if ((dataBufferPktInit2M[ROUTE_LONG_HEADER]   == 0x00) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +1] == 0x00) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +2]  == 0x00) &&
                 (dataBufferPktInit2M[ROUTE_LONG_HEADER+3] == 0x20) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +4] == 0x66) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +5]  == 0x74) &&
                 (dataBufferPktInit2M[ROUTE_LONG_HEADER+6] == 0x79) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +7] == 0x70) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +8]  == 0x68) &&
              	 (dataBufferPktInit2M[ROUTE_LONG_HEADER+9] == 0x76) && (dataBufferPktInit2M[ROUTE_LONG_HEADER+10] == 0x63) && (dataBufferPktInit2M[ROUTE_LONG_HEADER+11]  == 0x31) &&
               	 (dataBufferPktInit2M[pkt_size-12] == 0x00) && (dataBufferPktInit2M[pkt_size-11] == 0x29) && (dataBufferPktInit2M[pkt_size-10] == 0x38) &&
              	 (dataBufferPktInit2M[pkt_size- 9] == 0x3b) && (dataBufferPktInit2M[pkt_size- 8] == 0x00) && (dataBufferPktInit2M[pkt_size- 7] == 0x00) &&
              	 (dataBufferPktInit2M[pkt_size- 6] == 0x03) && (dataBufferPktInit2M[pkt_size- 5] == 0x00) && (dataBufferPktInit2M[pkt_size- 4] == 0x05) &&
                 (dataBufferPktInit2M[pkt_size- 3] == 0xfc) && (dataBufferPktInit2M[pkt_size- 2] == 0x40) && (dataBufferPktInit2M[pkt_size- 1] == 0x00)){ */

        	  std::cout<<"Jose123 "<<std::endl<<std::endl;
        	//Extração do video_2500000_init.mp4 a partir do pcap da Dektec
          /*if ((dataBufferPktInit2M[ROUTE_LONG_HEADER]   == 0x00) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +1] == 0x00) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +2]  == 0x00) &&
                (dataBufferPktInit2M[ROUTE_LONG_HEADER+3] == 0x20) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +4] == 0x66) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +5]  == 0x74) &&
            	(dataBufferPktInit2M[ROUTE_LONG_HEADER+6] == 0x79) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +7] == 0x70) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +8]  == 0x68) &&
            	(dataBufferPktInit2M[ROUTE_LONG_HEADER+9] == 0x76) && (dataBufferPktInit2M[ROUTE_LONG_HEADER+10] == 0x63) && (dataBufferPktInit2M[ROUTE_LONG_HEADER+11]  == 0x31) &&
            	(dataBufferPktInit2M[pkt_size-12] == 0x29) && (dataBufferPktInit2M[pkt_size-11] == 0x38) && (dataBufferPktInit2M[pkt_size-10] == 0x39) &&
				(dataBufferPktInit2M[pkt_size- 9] == 0x00) && (dataBufferPktInit2M[pkt_size- 8] == 0x00) && (dataBufferPktInit2M[pkt_size- 7] == 0x03) &&
				(dataBufferPktInit2M[pkt_size- 6] == 0x00) && (dataBufferPktInit2M[pkt_size- 5] == 0x05) && (dataBufferPktInit2M[pkt_size- 4] == 0xec) &&
                (dataBufferPktInit2M[pkt_size- 3] == 0x40) && (dataBufferPktInit2M[pkt_size- 2] == 0x00) && (dataBufferPktInit2M[pkt_size- 1] == 0x00)){*/
            	
            if ((dataBufferPktInit2M[ROUTE_LONG_HEADER]   == 0x00) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +1] == 0x00) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +2]  == 0x00) &&
                (dataBufferPktInit2M[ROUTE_LONG_HEADER+3] == 0x20) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +4] == 0x66) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +5]  == 0x74) &&
               	(dataBufferPktInit2M[ROUTE_LONG_HEADER+6] == 0x79) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +7] == 0x70) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +8]  == 0x68) &&
               	(dataBufferPktInit2M[ROUTE_LONG_HEADER+9] == 0x76) && (dataBufferPktInit2M[ROUTE_LONG_HEADER+10] == 0x63) && (dataBufferPktInit2M[ROUTE_LONG_HEADER+11]  == 0x31) &&
               	(dataBufferPktInit2M[pkt_size-12] == 0x29) && (dataBufferPktInit2M[pkt_size-11] == 0x38) && (dataBufferPktInit2M[pkt_size-10] == 0x3b) &&
                (dataBufferPktInit2M[pkt_size- 9] == 0x00) && (dataBufferPktInit2M[pkt_size- 8] == 0x00) && (dataBufferPktInit2M[pkt_size- 7] == 0x03) &&
            	(dataBufferPktInit2M[pkt_size- 6] == 0x00) && (dataBufferPktInit2M[pkt_size- 5] == 0x05) && (dataBufferPktInit2M[pkt_size- 4] == 0xfc) &&
            	(dataBufferPktInit2M[pkt_size- 3] == 0x40) && (dataBufferPktInit2M[pkt_size- 2] == 0x00) && (dataBufferPktInit2M[pkt_size- 1] == 0x00)){

              std::cout<<"Joa02 "<<std::endl<<std::endl;

              for(int j=ROUTE_LONG_HEADER;j<MAX_UDP_PACK_LENGTH;j++) { //j deve comecar no inicio do buffer e crescer ate seu comprimento => comp. header route 36 bytes no caso do init 2M
                video_2M5_mp4.write((const char*)&dataBufferPktInit2M[j],sizeof(char));
              }
              std::cout<<"Joa023 "<<std::endl<<std::endl;
            }
          break;

          case HDR_LEN_20_BYTES: //0x04 - 2nd portion of video_2500000_init.mp4 file
            hel = dataBufferPktInit2M[17];
            std::cout<<"HEL = 0x" << std::hex << hel <<std::endl;

            hec = dataBufferPktInit2M[18]*0x100 + dataBufferPktInit2M[19];
            std::cout<<"HEC = 0x" << std::hex << hec <<std::endl;

            //Extração do video_2500000_init.mp4 a partir do pcap do George
         /* if ((dataBufferPktInit2M[ROUTE_SHORT_HEADER] == 0x00) && (dataBufferPktInit2M[ROUTE_SHORT_HEADER+1]  == 0x03) && (dataBufferPktInit2M[ROUTE_SHORT_HEADER+2]   == 0x00) &&
           		(dataBufferPktInit2M[ROUTE_SHORT_HEADER+3] == 0x04) && (dataBufferPktInit2M[ROUTE_SHORT_HEADER+4]  == 0xb5) && (dataBufferPktInit2M[ROUTE_SHORT_HEADER+5]   == 0x62) &&
				(dataBufferPktInit2M[ROUTE_SHORT_HEADER+6] == 0x07) && (dataBufferPktInit2M[ROUTE_SHORT_HEADER+7]  == 0x80) && (dataBufferPktInit2M[ROUTE_SHORT_HEADER+8]   == 0x04) &&
				(dataBufferPktInit2M[ROUTE_SHORT_HEADER+9] == 0x40) && (dataBufferPktInit2M[ROUTE_SHORT_HEADER+10] == 0xa0) && (dataBufferPktInit2M[ROUTE_SHORT_HEADER+11]  == 0x00) &&
				(dataBufferPktInit2M[INIT_2M5_CONTINUITY_LENGTH-12] == 0x63) && (dataBufferPktInit2M[INIT_2M5_CONTINUITY_LENGTH-11] == 0x73) && (dataBufferPktInit2M[INIT_2M5_CONTINUITY_LENGTH-10] == 0x74) &&
				(dataBufferPktInit2M[INIT_2M5_CONTINUITY_LENGTH- 9] == 0x67) && (dataBufferPktInit2M[INIT_2M5_CONTINUITY_LENGTH- 8] == 0x00) && (dataBufferPktInit2M[INIT_2M5_CONTINUITY_LENGTH- 7] == 0x00) &&
				(dataBufferPktInit2M[INIT_2M5_CONTINUITY_LENGTH- 6] == 0x00) && (dataBufferPktInit2M[INIT_2M5_CONTINUITY_LENGTH- 5] == 0x00) && (dataBufferPktInit2M[INIT_2M5_CONTINUITY_LENGTH- 4] == 0x00) &&
				(dataBufferPktInit2M[INIT_2M5_CONTINUITY_LENGTH- 3] == 0x00) && (dataBufferPktInit2M[INIT_2M5_CONTINUITY_LENGTH- 2] == 0x03) && (dataBufferPktInit2M[INIT_2M5_CONTINUITY_LENGTH- 1] == 0xe9)){*/

            //2ª Alternativa para Pcap do George
/*          if ((dataBufferPktInit2M[ROUTE_SHORT_HEADER]   == 0x00) && (dataBufferPktInit2M[ROUTE_SHORT_HEADER+1]  == 0x03) && (dataBufferPktInit2M[ROUTE_SHORT_HEADER+2]   == 0x00) &&
                (dataBufferPktInit2M[ROUTE_SHORT_HEADER+3] == 0x04) && (dataBufferPktInit2M[ROUTE_SHORT_HEADER+4]  == 0xb5) && (dataBufferPktInit2M[ROUTE_SHORT_HEADER+5]   == 0x62) &&
                (dataBufferPktInit2M[ROUTE_SHORT_HEADER+6] == 0x07) && (dataBufferPktInit2M[ROUTE_SHORT_HEADER+7]  == 0x80) && (dataBufferPktInit2M[ROUTE_SHORT_HEADER+8]   == 0x04) &&
                (dataBufferPktInit2M[ROUTE_SHORT_HEADER+9] == 0x40) && (dataBufferPktInit2M[ROUTE_SHORT_HEADER+10] == 0xa0) && (dataBufferPktInit2M[ROUTE_SHORT_HEADER+11]  == 0x00) &&
                (dataBufferPktInit2M[pkt_size-12] == 0x63) && (dataBufferPktInit2M[pkt_size-11] == 0x73) && (dataBufferPktInit2M[pkt_size-10] == 0x74) &&
                (dataBufferPktInit2M[pkt_size- 9] == 0x67) && (dataBufferPktInit2M[pkt_size- 8] == 0x00) && (dataBufferPktInit2M[pkt_size- 7] == 0x00) &&
                (dataBufferPktInit2M[pkt_size- 6] == 0x00) && (dataBufferPktInit2M[pkt_size- 5] == 0x00) && (dataBufferPktInit2M[pkt_size- 4] == 0x00) &&
		        (dataBufferPktInit2M[pkt_size- 3] == 0x00) && (dataBufferPktInit2M[pkt_size- 2] == 0x03) && (dataBufferPktInit2M[pkt_size- 1] == 0xe9)){ */
            std::cout<<"Jose124 "<<std::endl<<std::endl;
            
            //Extração do video_2500000_init.mp4 a partir do pcap da Dektec
            if ((dataBufferPktInit2M[ROUTE_SHORT_HEADER]   == 0x03) && (dataBufferPktInit2M[ROUTE_SHORT_HEADER+1]  == 0x00) && (dataBufferPktInit2M[ROUTE_SHORT_HEADER+2]   == 0x04) &&
                (dataBufferPktInit2M[ROUTE_SHORT_HEADER+3] == 0xb5) && (dataBufferPktInit2M[ROUTE_SHORT_HEADER+4]  == 0x62) && (dataBufferPktInit2M[ROUTE_SHORT_HEADER+5]   == 0x07) &&
                (dataBufferPktInit2M[ROUTE_SHORT_HEADER+6] == 0x80) && (dataBufferPktInit2M[ROUTE_SHORT_HEADER+7]  == 0x04) && (dataBufferPktInit2M[ROUTE_SHORT_HEADER+8]   == 0x40) &&
                (dataBufferPktInit2M[ROUTE_SHORT_HEADER+9] == 0xa4) && (dataBufferPktInit2M[ROUTE_SHORT_HEADER+10] == 0x40) && (dataBufferPktInit2M[ROUTE_SHORT_HEADER+11]  == 0xf0) &&
                (dataBufferPktInit2M[pkt_size-12] == 0x63) && (dataBufferPktInit2M[pkt_size-11] == 0x73) && (dataBufferPktInit2M[pkt_size-10] == 0x74) &&
                (dataBufferPktInit2M[pkt_size- 9] == 0x67) && (dataBufferPktInit2M[pkt_size- 8] == 0x00) && (dataBufferPktInit2M[pkt_size- 7] == 0x00) &&
                (dataBufferPktInit2M[pkt_size- 6] == 0x00) && (dataBufferPktInit2M[pkt_size- 5] == 0x00) && (dataBufferPktInit2M[pkt_size- 4] == 0x00) &&
           	    (dataBufferPktInit2M[pkt_size- 3] == 0x00) && (dataBufferPktInit2M[pkt_size- 2] == 0x03) && (dataBufferPktInit2M[pkt_size- 1] == 0xe9)){

              std::cout<<"Joa03 "<<std::endl<<std::endl;
              init_2M5_control = 1;

            //for(int j=ROUTE_SHORT_HEADER;j<INIT_2M5_CONTINUITY_LENGTH;j++) { //j deve comecar no inicio do buffer e crescer ate seu comprimento => comp. header route 36 bytes no caso do init 2M
           	  for(int j=ROUTE_SHORT_HEADER;j<pkt_size; j++){ //j deve comecar no inicio do buffer e crescer ate seu comprimento => comp. header route 36 bytes no caso do init 2M

                video_2M5_mp4.write((const char*)&dataBufferPktInit2M[j],sizeof(char));
              }
              video_2M5_mp4.flush();//descarrega memoria antes de fechar.
              video_2M5_mp4.close();
            }
          break;
        }
      }// video_2500000_init.mp4 extraction end

    //Extracting video segments
   // Creates the BL name of the object to binary video file (mp4v) according to toi and tsi coordinates
      if ((tsi == BL_INDICATOR) && (previous_bl_toi != toi) && (previous_bl_toi < toi) && (toi != TOI_XML_PKT_1) && (toi != TOI_XML_OTHERS)){
    	std::cout << "Previous BL TOI = " << std::dec << previous_bl_toi << std::endl;

        //closes video seg (binary) previously opened.
    	bl_bin_file.flush();
    	bl_bin_file.close();

        //creates name for the new binary (new video segment)
        toi_string = (std::to_string(toi));
        desired_bl_file_name = "video-2000000-";
        desired_bl_file_name.append(toi_string);
        desired_bl_file_name += ".mp4v";
        std::cout << "Nome do arquivo de video BL desejado => " << desired_bl_file_name <<std::endl;
      }

      // Creates the EL name of the object to binary video file (mp4v) according to toi and tsi coordinates
      if ((tsi == EL_INDICATOR) && (previous_el_toi != toi) && (previous_el_toi < toi) && (toi != TOI_XML_PKT_1) && (toi != TOI_XML_OTHERS)){
        std::cout << "Previous EL TOI = " << std::dec << previous_el_toi << std::endl;

        //closes video seg (binary) previously opened.
        el_bin_file.flush();
        el_bin_file.close();

        //creates name for the new binary (new video segment)
        toi_string = (std::to_string(toi));
        desired_el_file_name = "video-2500000-";
        desired_el_file_name.append(toi_string);
        desired_el_file_name += ".mp4v";
        std::cout << "Nome do arquivo de video EL desejado => " << desired_el_file_name <<std::endl;
      }

      // neste momento fazendo if somente para o BL
      if(codepoint == CP_AV){ //0x8
        switch (tsi){
          case BL_INDICATOR: //0x64
            if (hdrLen == HDR_LEN_36_BYTES){
              std::cout<< "Pacote do 2º seg BL 36 bytes " << std::endl; // print on screen
              pacote = 1;
      	      if (dataBufferPktInit2M[ROUTE_LONG_HEADER +3] != 0x20){
      	    	std::cout<< "1º Pacote do 2º seg BL 36 bytes " << std::endl;
				bl_bin_file.open(desired_bl_file_name, std::ios::binary | std::ios::out);
                //for(int j=ROUTE_LONG_HEADER;j<MAX_UDP_PACK_LENGTH;j++) { //j deve comecar no inicio do buffer e crescer ate seu comprimento => comp. header route 36 bytes no caso do init 2M
                for(int j=ROUTE_LONG_HEADER;j<pkt_size;j++) { //j deve comecar no inicio do buffer e crescer ate seu comprimento => comp. header route 36 bytes no caso do init 2M
            	  bl_bin_file.write((const char*)&dataBufferPktInit2M[j],sizeof(char));
                }
      	      }
            }

            //else if () {

            //}

            else { // hdrLen == HDR_LEN_20_BYTES)
              hel = dataBufferPktInit2M[17];
              std::cout<<"HEL = 0x" << std::hex << hel <<std::endl;
              hec = dataBufferPktInit2M[18]*0x100 + dataBufferPktInit2M[19];
              std::cout<<"HEC = 0x" << std::hex << hec <<std::endl;
              pacote ++;
              std::cout<< "Pacote do 2º seg BL = " << std::dec << pacote << std::endl;
              for(int j=ROUTE_SHORT_HEADER;j<pkt_size;j++) {
                bl_bin_file.write((const char*)&dataBufferPktInit2M[j],sizeof(char));
           	  }
            }
          break;

          case EL_INDICATOR: //0x65
            if (hdrLen == HDR_LEN_36_BYTES){
        	  if (dataBufferPktInit2M[ROUTE_LONG_HEADER +3] != 0x20){
                el_bin_file.open(desired_el_file_name, std::ios::binary | std::ios::out);
                //for(int j=ROUTE_LONG_HEADER;j<MAX_UDP_PACK_LENGTH;j++) { //j deve comecar no inicio do buffer e crescer ate seu comprimento => comp. header route 36 bytes no caso do init 2M
                for(int j=ROUTE_LONG_HEADER;j<pkt_size;j++) { //j deve comecar no inicio do buffer e crescer ate seu comprimento => comp. header route 36 bytes no caso do init 2M
                  el_bin_file.write((const char*)&dataBufferPktInit2M[j],sizeof(char));
                }
              }
            }
            //tentando remediar possiveis influencias do segundo pacote do init 2M5
            else { // hdrLen == HDR_LEN_20_BYTES)
              if (init_2M5_control != 1){
                hel = dataBufferPktInit2M[17];
                std::cout<<"HEL = 0x" << std::hex << hel <<std::endl;
                hec = dataBufferPktInit2M[18]*0x100 + dataBufferPktInit2M[19];
                std::cout<<"HEC = 0x" << std::hex << hec <<std::endl;
                std::cout<< "Pacote do 2º seg EL = " << std::dec << pacote << std::endl;
                for(int j=ROUTE_SHORT_HEADER;j<pkt_size;j++) {
                  el_bin_file.write((const char*)&dataBufferPktInit2M[j],sizeof(char));
                }
              }
            }
          break;
        }// switch tsi
      }//if(codepoint == CP_AV){ //0x8

      //daqui para frente serve de gabarito/log/debugging
	  std::cout<<std::endl;
	  std::cout<<"Message [extracted]"<<std::endl; // print on screen

	  for (int j=0; j<pkt_size; j++) {
	    std::cout<<"0x" << std::hex<<(int)dataBufferPktInit2M[j]<<" ";
	    if(j!=0 && (j+1)%10 == 0) { // escreve 10 caracteres por linha
		  std::cout<<std::endl;
		}
	  }
	  std::cout<<std::endl;
	  //fim do gabarito

      server.message_buffer[0].status=MESSAGE_STATUS_FREE; //libera buffer depois de receber a mensagem

      if (loop_control == ENDING_CONTROL){
        bl_bin_file.flush();//descarrega memoria antes de fechar.
    	bl_bin_file.close();
    	el_bin_file.flush();//descarrega memoria antes de fechar.
    	el_bin_file.close();
	    //exit(0); // pode-se apagar esta linha para ficar no loop infinito.
      }

      loop_control++;

      if (hdrLen == HDR_LEN_36_BYTES){ //0x8
    	if ((tsi == BL_INDICATOR) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +3] != 0x20)){
          previous_bl_tsi = tsi;
          previous_bl_toi = toi;
        }

    	if ((tsi == EL_INDICATOR) && (dataBufferPktInit2M[ROUTE_LONG_HEADER +3] != 0x20)){ // há ainda alguma condição do pacote do init 2M5 a ser considerada?
    	  previous_el_tsi = tsi;
    	  previous_el_toi = toi;
    	  std::cout << "HDR_LEN_36_BYTES EL Final if previous TOI = " << std::dec << previous_el_toi <<std::endl;
    	}

      }
      else {
        if (tsi == BL_INDICATOR){
    	  previous_bl_tsi = tsi;
    	  previous_bl_toi = toi;
        }

       if ((tsi == EL_INDICATOR) && (init_2M5_control != 1)){//{
          previous_el_tsi = tsi;
          previous_el_toi = toi;
          std::cout << "HDR_LEN_20_BYTES EL Final if previous TOI = " << std::dec << previous_el_toi <<std::endl;
        }
      }

      init_2M5_control = 0;

    }//  if(server.message_buffer[0].status!=MESSAGE_STATUS_FREE) {

  }//while (0)

  return (0);//main()
}


