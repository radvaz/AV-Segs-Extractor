All files must be compiled together
Developed over Ubuntu Linux platform

Compile command: sudo g++ *.cc -o udp_rec.o
run command: sudo ./udp_rec.o